# News Explorer — Local Web Application

## Run the website
1. Extract this project folder.
2. Open `web/index.html` in Chrome or Microsoft Edge.
3. Use search, categories, story cards, saved stories, related stories, topic matching, and reading planner.
4. No server, API key, internet connection, or database is required for the browser experience.

## Java source
The Java DSA engine is included separately in `src/NewsExplorer.java`. It is not required to open the browser website. With JDK installed, compile from the project root:
`javac -d out src/NewsExplorer.java`
Then run:
`java -cp out NewsExplorer`

## Content and scope
This is an offline academic demonstration using bundled sample news-style articles, not a live news service. Algorithm-driven functions operate on the bundled collection. See `docs/SYLLABUS_MAPPING.md` for implementation scope and limitations.
