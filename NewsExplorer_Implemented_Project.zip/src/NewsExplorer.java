import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

/**
 * News Explorer / TextHack: Advanced Algorithms Question Bank.
 * Single-file Java implementation. The algorithm engine deliberately avoids
 * java.util.* collections; custom arrays, queues, sorting and graph structures
 * are used instead. Java standard I/O is used only for console input/output.
 *
 * Dataset note: a small bundled educational corpus is embedded below. For a
 * genuine Indian-language Wikipedia corpus, load licensed/exported article text
 * into the same Article arrays; this program does not download Wikipedia.
 */
public class NewsExplorer {
    static final int MAX_ARTICLES = 24;
    static Article[] articles = new Article[MAX_ARTICLES];
    static int articleCount = 0;
    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

    static class Article {
        int id, views, readingTime, relevance;
        String title, category, content;
        Article(int id, String title, String category, String content, int views, int minutes, int relevance) {
            this.id=id; this.title=title; this.category=category; this.content=content;
            this.views=views; this.readingTime=minutes; this.relevance=relevance;
        }
        String searchable() { return title + " " + category + " " + content; }
        void print() {
            System.out.println("\n["+id+"] "+title+"\nCategory: "+category+" | Views: "+views+
                " | Reading time: "+readingTime+" min | Relevance: "+relevance+"/10\n"+content);
        }
    }

    static void add(int id,String title,String category,String content,int views,int minutes,int relevance) {
        if(articleCount<articles.length) articles[articleCount++]=new Article(id,title,category,content,views,minutes,relevance);
    }
    static void loadCorpus() {
        add(1,"India launches artificial intelligence research mission","Artificial Intelligence","A national artificial intelligence research mission can support universities, startups and research laboratories working on useful AI systems. Key priorities include access to computing resources, quality datasets, local-language tools and responsible development. Researchers may apply AI to agriculture, healthcare, education and public services, while also studying privacy, fairness and reliability. Collaboration between students, industry and academic institutions can help turn research into practical applications. This is an illustrative project article, not a verified current announcement.",9500,5,9);
        add(2,"Hyderabad technology companies expand AI research","Technology","Technology companies in Hyderabad expand artificial intelligence research, startups and software development.",7200,4,8);
        add(3,"India wins international cricket championship","Sports","India’s cricket team delivered a memorable performance in a closely contested international final. The batters built partnerships and kept the scoreboard moving, while the bowlers focused on line, length and pressure during crucial overs. Fielders contributed by saving runs and taking important catches. The result highlighted teamwork, preparation and the ability to remain calm in high-pressure moments. For fans, a championship victory can become a shared celebration and an inspiration for young players. This is an illustrative project article, not a verified report of a specific match.",15000,3,10);
        add(4,"Universities introduce digital learning platforms","Education","Indian universities introduce digital learning platforms and online educational resources for students.",5400,6,7);
        add(5,"Indian scientists develop renewable energy technology","Science","Scientists develop renewable energy technology using solar power, wind and improved energy storage.",8100,7,9);
        add(6,"Artificial intelligence transforms Indian healthcare","Artificial Intelligence","AI systems support healthcare diagnosis, medical research and hospital resource planning.",8900,5,9);
        add(7,"Hyderabad hosts a technology innovation event","Technology","Hyderabad hosts a technology innovation event where software startups demonstrate new products.",6500,4,8);
        add(8,"India announces a major space research program","Science","India announces a space research program involving satellites, scientific instruments and exploration.",7300,6,8);
        add(9,"Indian universities expand computer science programs","Education","Universities expand computer science education, algorithms courses and practical laboratory learning.",4700,5,7);
        add(10,"Cricket team prepares for the world tournament","Sports","The Indian cricket team is preparing for a major international tournament, with attention on fitness, batting combinations, bowling plans and fielding practice. Team preparation includes reviewing opponents, adapting to pitch conditions and building partnerships under pressure. Supporters will be watching how experienced players and emerging talent contribute. This is an illustrative project article rather than a verified current sports report.",11000,3,8);
        add(11,"Telangana promotes water conservation","Environment","Telangana communities promote water conservation, rainwater harvesting and sustainable agriculture.",4100,4,7);
        add(12,"Solar energy project begins in rural India","Science","A rural solar energy project provides electricity and supports local schools and health centres.",6200,5,8);
        add(13,"Digital public services expand in India","Technology","Digital public services use secure software and data systems to improve access to information.",7900,4,8);
        add(14,"Students build an intelligent waste management application","Technology","Students build a waste management application that classifies waste and recommends responsible disposal.",3800,5,8);
        add(15,"Telugu language computing and digital archives","Language Technology","Digital archives preserve Telugu language material and support Indian-language computing research.",3300,6,8);
        add(16,"తెలుగు భాష డిజిటల్ సాంకేతికత","Language Technology","తెలుగు భాషా సమాచారం, డిజిటల్ ఆర్కైవ్‌లు మరియు భాషా సాంకేతిక పరిశోధన.",2100,4,7);
        add(17,"భారతదేశంలో సౌర శక్తి పరిశోధన","Science","సౌర శక్తి పరిశోధన మరియు పర్యావరణ పరిరక్షణ భారతదేశంలో ముఖ్యమైన అంశాలు.",1900,4,7);
        add(18,"Indian language Wikipedia knowledge graph","Language Technology","Wikipedia articles connect concepts through citations, links and shared subjects.",2900,5,8);
    }

    // Browse bundled news by topic; works offline and never connects to websites.
    static void browseNewsByTopic() {
        String[] topics = {"Top India News", "Technology", "Sports", "Education", "Science", "Environment", "Language Technology"};
        String[] categories = {"", "", "Technology", "Sports", "Education", "Science", "Environment", "Language Technology"};
        System.out.println("\n========== CHOOSE A NEWS TOPIC ==========");
        for (int i=0;i<topics.length;i++) System.out.println(" "+(i+1)+". "+topics[i]);
        System.out.println(" 0. Back to main menu");
        int topic=readInt("Choose a topic: ",0,topics.length);
        if(topic==0)return;
        int[] matches=new int[MAX_ARTICLES]; int count=0;
        for(int i=0;i<articleCount;i++) if(topic==1 || articles[i].category.equalsIgnoreCase(categories[topic])) matches[count++]=i;
        if(count==0){System.out.println("No bundled news is available for this topic yet.");return;}
        System.out.println("\n========== "+topics[topic-1].toUpperCase()+" — NEWS ==========");
        for(int j=0;j<count;j++) System.out.println(" "+(j+1)+". "+articles[matches[j]].title);
        System.out.println(" 0. Back to topic list");
        int choice=readInt("Choose news to read: ",0,count);
        if(choice==0){browseNewsByTopic();return;}
        Article a=articles[matches[choice-1]];
        System.out.println("\n================ NEWS ARTICLE ================");
        System.out.println(a.title);
        System.out.println("Topic: "+a.category+" | Estimated reading time: "+a.readingTime+" min");
        System.out.println();
        System.out.println(a.content);
        System.out.println("\n--- Key points ---");
        System.out.println("- Topic: "+a.category);
        System.out.println("- Read the article above for the main context and details.");
        System.out.println("- This content is stored locally in the project; no website is contacted.");
        System.out.println("==============================================");
    }


    // All user-facing searches use numbered choices instead of free-text prompts.
    static String chooseSearchPhrase() {
        String[] choices={"artificial intelligence","cricket","technology","renewable energy","education","solar energy","Telugu language","healthcare","water conservation"};
        System.out.println("\n--- Choose a news phrase ---");
        for(int i=0;i<choices.length;i++)System.out.println(" "+(i+1)+". "+choices[i]);
        System.out.println(" 0. Back");
        int c=readInt("Choose a phrase: ",0,choices.length);
        return c==0?null:choices[c-1];
    }
    static Article chooseArticle(String prompt) {
        System.out.println("\n--- Choose a news article ---");
        for(int i=0;i<articleCount;i++)System.out.println(" "+(i+1)+". "+articles[i].title+" ["+articles[i].category+"]");
        System.out.println(" 0. Back");
        int c=readInt(prompt,0,articleCount);
        return c==0?null:articles[c-1];
    }
    static String chooseArticleText(String prompt) {
        Article a=chooseArticle(prompt);
        return a==null?null:a.title+". "+a.content;
    }

    // -------------------- Basic input and custom data structures --------------------
    static String read(String prompt) {
        System.out.print(prompt);
        try { String s=in.readLine(); return s==null?"":s.trim(); }
        catch(IOException e) { return ""; }
    }
    static int readInt(String prompt,int low,int high) {
        while(true) {
            String s=read(prompt);
            try { int v=Integer.parseInt(s); if(v>=low&&v<=high)return v; }
            catch(NumberFormatException ignored) { }
            System.out.println("Enter an integer from "+low+" to "+high+".");
        }
    }
    static Article byId(int id) { for(int i=0;i<articleCount;i++) if(articles[i].id==id)return articles[i]; return null; }
    static void printCorpus() { for(int i=0;i<articleCount;i++) System.out.println(articles[i].id+". "+articles[i].title+" ["+articles[i].category+"]"); }
    static boolean containsIgnoreCase(String text,String pattern) { return kmp(text.toLowerCase(),pattern.toLowerCase())>=0; }
    static void swap(int[] a,int i,int j){int t=a[i];a[i]=a[j];a[j]=t;}

    // -------------------- Module 2: String algorithms --------------------
    static int[] buildLps(String p) {
        int[] lps=new int[p.length()]; int len=0,i=1;
        while(i<p.length()) { if(p.charAt(i)==p.charAt(len)) lps[i++]=++len; else if(len>0)len=lps[len-1]; else lps[i++]=0; }
        return lps;
    }
    static int kmp(String text,String pattern) {
        if(pattern.length()==0)return 0; int[] lps=buildLps(pattern); int i=0,j=0;
        while(i<text.length()) { if(text.charAt(i)==pattern.charAt(j)){i++;j++;if(j==pattern.length())return i-j;} else if(j>0)j=lps[j-1]; else i++; }
        return -1;
    }
    static int[] zFunction(String s) {
        int n=s.length(); int[] z=new int[n]; int l=0,r=0;
        for(int i=1;i<n;i++){if(i<=r)z[i]=Math.min(r-i+1,z[i-l]);while(i+z[i]<n&&s.charAt(z[i])==s.charAt(i+z[i]))z[i]++;if(i+z[i]-1>r){l=i;r=i+z[i]-1;}}
        return z;
    }
    static int zSearch(String text,String p) {
        if(p.length()==0)return 0; String joined=p+"\u0001"+text; int[] z=zFunction(joined);
        for(int i=p.length()+1;i<joined.length();i++)if(z[i]>=p.length())return i-p.length()-1; return -1;
    }
    static long addMod(long a,long b,long mod){return a>=mod-b?a-(mod-b):a+b;}
    static long mulMod(long a,long b,long mod){long r=0;a%=mod;while(b>0){if((b&1L)!=0)r=addMod(r,a,mod);b>>=1;if(b>0)a=addMod(a,a,mod);}return r;}
    static long modPow(long a,long e,long mod){long r=1%mod;a%=mod;while(e>0){if((e&1L)!=0)r=mulMod(r,a,mod);a=mulMod(a,a,mod);e>>=1;}return r;}
    static int rabinKarp(String text,String p) {
        int n=text.length(),m=p.length();if(m==0)return 0;if(m>n)return -1;
        long mod1=1000000007L,mod2=1000000009L,base=257L; long ph1=0,th1=0,ph2=0,th2=0,pow1=1,pow2=1;
        for(int i=0;i<m;i++){ph1=(ph1*base+p.charAt(i))%mod1;th1=(th1*base+text.charAt(i))%mod1;ph2=(ph2*base+p.charAt(i))%mod2;th2=(th2*base+text.charAt(i))%mod2;if(i<m-1){pow1=pow1*base%mod1;pow2=pow2*base%mod2;}}
        for(int i=0;i<=n-m;i++){
            if(ph1==th1&&ph2==th2&&text.regionMatches(i,p,0,m))return i;
            if(i<n-m){th1=(th1-(text.charAt(i)*pow1)%mod1+mod1)%mod1;th1=(th1*base+text.charAt(i+m))%mod1;th2=(th2-(text.charAt(i)*pow2)%mod2+mod2)%mod2;th2=(th2*base+text.charAt(i+m))%mod2;}
        }return -1;
    }
    static int editDistance(String a,String b) {
        int[][] d=new int[a.length()+1][b.length()+1];for(int i=0;i<=a.length();i++)d[i][0]=i;for(int j=0;j<=b.length();j++)d[0][j]=j;
        for(int i=1;i<=a.length();i++)for(int j=1;j<=b.length();j++){int c=a.charAt(i-1)==b.charAt(j-1)?0:1;int x=d[i-1][j]+1;if(d[i][j-1]+1<x)x=d[i][j-1]+1;if(d[i-1][j-1]+c<x)x=d[i-1][j-1]+c;d[i][j]=x;}return d[a.length()][b.length()];
    }
    static int damerauLevenshtein(String a,String b) {
        int[][] d=new int[a.length()+1][b.length()+1];for(int i=0;i<=a.length();i++)d[i][0]=i;for(int j=0;j<=b.length();j++)d[0][j]=j;
        for(int i=1;i<=a.length();i++)for(int j=1;j<=b.length();j++){int cost=a.charAt(i-1)==b.charAt(j-1)?0:1;d[i][j]=Math.min(Math.min(d[i-1][j]+1,d[i][j-1]+1),d[i-1][j-1]+cost);if(i>1&&j>1&&a.charAt(i-1)==b.charAt(j-2)&&a.charAt(i-2)==b.charAt(j-1))d[i][j]=Math.min(d[i][j],d[i-2][j-2]+1);}return d[a.length()][b.length()];
    }
    static void fuzzySearch(String query) {
        int best=999; boolean any=false;
        for(int i=0;i<articleCount;i++){int d=editDistance(query.toLowerCase(),articles[i].title.toLowerCase());if(d<best)best=d;}
        System.out.println("Closest title matches (Levenshtein distance <= "+Math.max(3,best+2)+"):");
        for(int i=0;i<articleCount;i++){int d=editDistance(query.toLowerCase(),articles[i].title.toLowerCase());if(d<=Math.max(3,best+2)){System.out.println("distance="+d+" | "+articles[i].title);any=true;}}
        if(!any)System.out.println("No close title found.");
        System.out.println("Damerau-Levenshtein example: distance to first title = "+damerauLevenshtein(query.toLowerCase(),articles[0].title.toLowerCase()));
    }
    // Trie with failure links for Aho-Corasick. ASCII-folded educational version.
    static class ACNode { int[] next=new int[128]; int fail=0; boolean output=false; ACNode(){for(int i=0;i<128;i++)next[i]=-1;} }
    static class IntQueue { int[] a;int head=0,tail=0;IntQueue(int n){a=new int[n+5];}void add(int x){if(tail<a.length)a[tail++]=x;}boolean empty(){return head==tail;}int remove(){return a[head++];} }
    static void ahoDemo(String text,String[] patterns) {
        ACNode[] nodes=new ACNode[2000];for(int i=0;i<nodes.length;i++)nodes[i]=new ACNode();int used=1;
        for(int p=0;p<patterns.length;p++){int state=0;String pat=patterns[p].toLowerCase();for(int j=0;j<pat.length();j++){int c=pat.charAt(j);if(c>=128)continue;if(nodes[state].next[c]==-1){nodes[state].next[c]=used++;}state=nodes[state].next[c];}nodes[state].output=true;}
        IntQueue q=new IntQueue(used+5);
        for(int c=0;c<128;c++){int v=nodes[0].next[c];if(v==-1)nodes[0].next[c]=0;else{nodes[v].fail=0;q.add(v);}}
        while(!q.empty()){int v=q.remove();for(int c=0;c<128;c++){int u=nodes[v].next[c];if(u==-1)nodes[v].next[c]=nodes[nodes[v].fail].next[c];else{nodes[u].fail=nodes[nodes[v].fail].next[c];nodes[u].output=nodes[u].output||nodes[nodes[u].fail].output;q.add(u);}}}
        int state=0;boolean found=false;for(int i=0;i<text.length();i++){int c=Character.toLowerCase(text.charAt(i));if(c>=128)c=0;state=nodes[state].next[c];if(nodes[state].output){System.out.println("At least one pattern matched ending at text index "+i);found=true;}}
        if(!found)System.out.println("No patterns matched.");System.out.println("Aho-Corasick: built trie and failure links for "+patterns.length+" patterns; O(text length + total pattern length + matches).");
    }
    // Practical suffix array via prefix doubling; O(n log^2 n) with comparison sort.
    static void sortSuffixes(int[] sa,int[] rank,int k) {
        // Merge sort indices using (rank[i], rank[i+k]) comparator.
        int n=sa.length;int[] tmp=new int[n];mergeSortSuffix(sa,tmp,0,n,rank,k);
    }
    static boolean suffixLess(int i,int j,int[] rank,int k){if(rank[i]!=rank[j])return rank[i]<rank[j];int a=i+k<rank.length?rank[i+k]:-1;int b=j+k<rank.length?rank[j+k]:-1;return a<b;}
    static void mergeSortSuffix(int[] a,int[] t,int lo,int hi,int[] rank,int k){if(hi-lo<=1)return;int mid=(lo+hi)/2;mergeSortSuffix(a,t,lo,mid,rank,k);mergeSortSuffix(a,t,mid,hi,rank,k);int i=lo,j=mid,p=lo;while(i<mid&&j<hi)t[p++]=suffixLess(a[i],a[j],rank,k)?a[i++]:a[j++];while(i<mid)t[p++]=a[i++];while(j<hi)t[p++]=a[j++];for(i=lo;i<hi;i++)a[i]=t[i];}
    static int[] suffixArray(String s){int n=s.length();int[] sa=new int[n],rank=new int[n],next=new int[n];for(int i=0;i<n;i++){sa[i]=i;rank[i]=s.charAt(i);}for(int k=1;k<n;k*=2){sortSuffixes(sa,rank,k);next[sa[0]]=0;for(int i=1;i<n;i++)next[sa[i]]=next[sa[i-1]]+(suffixLess(sa[i-1],sa[i],rank,k)?1:0);for(int i=0;i<n;i++)rank[i]=next[i];if(rank[sa[n-1]]==n-1)break;if(k>n/2)break;}return sa;}
    static int[] lcpArray(String s,int[] sa){int n=s.length();int[] rank=new int[n],lcp=new int[n];for(int i=0;i<n;i++)rank[sa[i]]=i;int h=0;for(int i=0;i<n;i++){int r=rank[i];if(r==n-1){h=0;continue;}int j=sa[r+1];while(i+h<n&&j+h<n&&s.charAt(i+h)==s.charAt(j+h))h++;lcp[r]=h;if(h>0)h--;}return lcp;}
    static String ints(int[] a){StringBuilder b=new StringBuilder("[");for(int i=0;i<a.length;i++){if(i>0)b.append(", ");b.append(a[i]);}return b.append("]").toString();}

    // -------------------- Module 3: Dynamic programming --------------------
    static int weightedEditDistance(String a,String b,int insertCost,int deleteCost,int replaceCost){int[][] d=new int[a.length()+1][b.length()+1];for(int i=1;i<=a.length();i++)d[i][0]=i*deleteCost;for(int j=1;j<=b.length();j++)d[0][j]=j*insertCost;for(int i=1;i<=a.length();i++)for(int j=1;j<=b.length();j++){int rep=d[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:replaceCost);d[i][j]=Math.min(rep,Math.min(d[i-1][j]+deleteCost,d[i][j-1]+insertCost));}return d[a.length()][b.length()];}
    static int alignmentGlobal(String a,String b,int match,int mismatch,int gap){int[][] d=new int[a.length()+1][b.length()+1];for(int i=1;i<=a.length();i++)d[i][0]=d[i-1][0]+gap;for(int j=1;j<=b.length();j++)d[0][j]=d[0][j-1]+gap;for(int i=1;i<=a.length();i++)for(int j=1;j<=b.length();j++)d[i][j]=Math.max(d[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?match:mismatch),Math.max(d[i-1][j]+gap,d[i][j-1]+gap));return d[a.length()][b.length()];}
    static int alignmentLocal(String a,String b,int match,int mismatch,int gap){int[][] d=new int[a.length()+1][b.length()+1];int best=0;for(int i=1;i<=a.length();i++)for(int j=1;j<=b.length();j++){d[i][j]=Math.max(0,Math.max(d[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?match:mismatch),Math.max(d[i-1][j]+gap,d[i][j-1]+gap)));if(d[i][j]>best)best=d[i][j];}return best;}
    static long matrixChain(int[] p){int n=p.length-1;long[][] d=new long[n][n];for(int len=2;len<=n;len++)for(int i=0;i+len<=n;i++){int j=i+len-1;d[i][j]=Long.MAX_VALUE/4;for(int k=i;k<j;k++){long v=d[i][k]+d[k+1][j]+(long)p[i]*p[k+1]*p[j+1];if(v<d[i][j])d[i][j]=v;}}return d[0][n-1];}
    static long tspBitmask(int[][] cost){int n=cost.length;if(n>15)return -1;int states=1<<n;long inf=Long.MAX_VALUE/8;long[][] dp=new long[states][n];for(int m=0;m<states;m++)for(int j=0;j<n;j++)dp[m][j]=inf;dp[1][0]=0;for(int mask=1;mask<states;mask++){if((mask&1)==0)continue;for(int u=0;u<n;u++)if(dp[mask][u]<inf)for(int v=0;v<n;v++)if((mask&(1<<v))==0){int nm=mask|(1<<v);long val=dp[mask][u]+cost[u][v];if(val<dp[nm][v])dp[nm][v]=val;}}long ans=inf;for(int j=1;j<n;j++)if(dp[states-1][j]+cost[j][0]<ans)ans=dp[states-1][j]+cost[j][0];return ans;}
    static int sosDemo(){int n=3,size=1<<n;int[] f={1,2,3,4,5,6,7,8};int[] sos=new int[size];for(int m=0;m<size;m++)sos[m]=f[m];for(int bit=0;bit<n;bit++)for(int mask=0;mask<size;mask++)if((mask&(1<<bit))!=0)sos[mask]+=sos[mask^(1<<bit)];System.out.println("SOS DP subset sums for f=[1..8]: "+ints(sos));return n*size;}
    static int treeDfs(int node,int parent,int[][] g,int[] value,int[] total){int sum=value[node];for(int j=0;j<g[node].length;j++){int v=g[node][j];if(v!=parent)sum+=treeDfs(v,node,g,value,total);}total[node]=sum;return sum;}
    static long optimalBstDemo(){int n=3;double[] p={0.0,0.3,0.2,0.5};double[] q={0.0,0.05,0.05,0.05,0.05};double[][] e=new double[n+2][n+1],w=new double[n+2][n+1];int[][] root=new int[n+1][n+1];for(int i=1;i<=n+1;i++){e[i][i-1]=q[i-1];w[i][i-1]=q[i-1];}for(int len=1;len<=n;len++)for(int i=1;i<=n-len+1;i++){int j=i+len-1;e[i][j]=Double.POSITIVE_INFINITY;w[i][j]=w[i][j-1]+p[j]+q[j];for(int r=i;r<=j;r++){double v=e[i][r-1]+e[r+1][j]+w[i][j];if(v<e[i][j]){e[i][j]=v;root[i][j]=r;}}}System.out.printf("Optimal BST expected cost for 3 keys = %.3f (classic O(n^3) interval DP).%n",e[1][n]);return root[1][n];}
    static boolean hamiltonianPath(int[][] g,int n){if(n>20)return false;int states=1<<n;boolean[][] dp=new boolean[states][n];for(int i=0;i<n;i++)dp[1<<i][i]=true;for(int mask=1;mask<states;mask++)for(int v=0;v<n;v++)if(dp[mask][v])for(int u=0;u<n;u++)if(g[v][u]!=0&&(mask&(1<<u))==0)dp[mask|(1<<u)][u]=true;for(int v=0;v<n;v++)if(dp[states-1][v])return true;return false;}
    static int treeHeight(int u,int parent,int[][] g,int[] depth){int best=0;for(int i=0;i<g[u].length;i++){int v=g[u][i];if(v!=parent){int h=1+treeHeight(v,u,g,depth);if(h>best)best=h;}}depth[u]=best;return best;}
    static int treeDiameterDemo(){int[][] g={{1},{0,2},{1,3,4},{2},{2}};int[] d=new int[5];int h=treeHeight(0,-1,g,d);int diameter=0;for(int u=0;u<5;u++){int first=0,second=0;for(int j=0;j<g[u].length;j++){int v=g[u][j];int branch=1+d[v];if(v==0&&u==1)branch=1; if(branch>first){second=first;first=branch;}else if(branch>second)second=branch;}if(first+second>diameter)diameter=first+second;}System.out.println("Tree-DP example: rooted height = "+h+", rerooting idea computes answers for every root by passing parent-side information.");System.out.println("Centroid preview: a tree centroid is a node whose removal leaves components of size at most n/2; it can be found from subtree sizes.");return diameter;}
    static int treeSize(int u,int parent,int[][] g,int[] size){size[u]=1;for(int i=0;i<g[u].length;i++){int v=g[u][i];if(v!=parent)size[u]+=treeSize(v,u,g,size);}return size[u];}
    static int findCentroid(int u,int parent,int n,int[][] g,int[] size){boolean ok=n-size[u]<=n/2;for(int i=0;i<g[u].length;i++){int v=g[u][i];if(v!=parent){if(size[v]>n/2)ok=false;}}if(ok)return u;for(int i=0;i<g[u].length;i++){int v=g[u][i];if(v!=parent&&size[v]>n/2)return findCentroid(v,u,n,g,size);}return u;}
    static int treeDiameterBfs(int[][] g,int start){int n=g.length;int[] dist=new int[n],q=new int[n+1];for(int i=0;i<n;i++)dist[i]=-1;int h=0,z=0;q[z++]=start;dist[start]=0;int far=start;while(h<z){int u=q[h++];if(dist[u]>dist[far])far=u;for(int j=0;j<g[u].length;j++){int v=g[u][j];if(dist[v]<0){dist[v]=dist[u]+1;q[z++]=v;}}}return far;}
    static int treeDiameterLength(int[][] g){int a=treeDiameterBfs(g,0);int n=g.length;int[] dist=new int[n],q=new int[n+1];for(int i=0;i<n;i++)dist[i]=-1;int h=0,z=0;q[z++]=a;dist[a]=0;int best=0;while(h<z){int u=q[h++];if(dist[u]>best)best=dist[u];for(int j=0;j<g[u].length;j++){int v=g[u][j];if(dist[v]<0){dist[v]=dist[u]+1;q[z++]=v;}}}return best;}
    static void dpMenu(){System.out.println("\n--- Personalize your reading feed ---");String[] pairs={"kitten / sitting","cricket / cricket","technology / technlogy","education / eduction"};for(int i=0;i<pairs.length;i++)System.out.println(" "+(i+1)+". Compare "+pairs[i]);System.out.println(" 0. Use default comparison");int pick=readInt("Choose a comparison: ",0,pairs.length);String a="kitten",b="sitting";if(pick==1){a="kitten";b="sitting";}else if(pick==2){a="cricket";b="cricket";}else if(pick==3){a="technology";b="technlogy";}else if(pick==4){a="education";b="eduction";}System.out.println("Levenshtein = "+editDistance(a,b));System.out.println("Weighted edit (insert=1, delete=1, replace=2) = "+weightedEditDistance(a,b,1,1,2));System.out.println("Global alignment score (match=2,mismatch=-1,gap=-2) = "+alignmentGlobal(a,b,2,-1,-2));System.out.println("Local alignment score (Smith-Waterman) = "+alignmentLocal(a,b,2,-1,-2));System.out.println("Matrix-chain dimensions [10,30,5,60], minimum multiplications = "+matrixChain(new int[]{10,30,5,60}));int[][] c={{0,10,15,20},{10,0,35,25},{15,35,0,30},{20,25,30,0}};System.out.println("Bitmask TSP tour cost (4 cities) = "+tspBitmask(c));sosDemo();int[][] g={{1,2},{0,3},{0},{1}};int[] value={3,5,2,4},total=new int[4];System.out.println("Tree DP subtree sum rooted at node 0 = "+treeDfs(0,-1,g,value,total));optimalBstDemo();System.out.println("Hamiltonian path bitmask-DP sample = "+hamiltonianPath(new int[][]{{false?1:0,1,0,0},{1,0,1,0},{0,1,0,1},{0,0,1,0}},4));treeDiameterDemo();int[][] tg={{1},{0,2},{1,3,4},{2},{2}};int[] ts=new int[5];treeSize(0,-1,tg,ts);System.out.println("Tree diameter (two BFS traversals) = "+treeDiameterLength(tg)+" edges; centroid node = "+findCentroid(0,-1,5,tg,ts));System.out.println("DP note: bitmask TSP is O(2^n n^2); interval matrix-chain DP is O(n^3); SOS DP is O(n 2^n).");}

    // -------------------- Module 4: Flow, cut, matching, min-cost flow --------------------
    static class FlowEdge {int to,rev,cap,original,cost;FlowEdge(int t,int r,int c,int o,int co){to=t;rev=r;cap=c;original=o;cost=co;}}
    static class FlowGraph {
        FlowEdge[][] e;int[] deg;int n;
        FlowGraph(int n,int maxEdges){this.n=n;e=new FlowEdge[n][maxEdges];deg=new int[n];}
        void add(int u,int v,int cap){addCost(u,v,cap,0);}
        void addCost(int u,int v,int cap,int cost){FlowEdge a=new FlowEdge(v,deg[v],cap,cap,cost);FlowEdge b=new FlowEdge(u,deg[u],0,0,-cost);e[u][deg[u]++]=a;e[v][deg[v]++]=b;}
    }
    static boolean bfsLevel(FlowGraph g,int s,int t,int[] level){for(int i=0;i<g.n;i++)level[i]=-1;int[] q=new int[g.n+2];int h=0,z=0;q[z++]=s;level[s]=0;while(h<z){int u=q[h++];for(int i=0;i<g.deg[u];i++){FlowEdge e=g.e[u][i];if(e.cap>0&&level[e.to]<0){level[e.to]=level[u]+1;q[z++]=e.to;}}}return level[t]>=0;}
    static int dfsFlow(FlowGraph g,int u,int t,int pushed,int[] level,int[] ptr){if(u==t||pushed==0)return pushed;while(ptr[u]<g.deg[u]){FlowEdge e=g.e[u][ptr[u]];if(e.cap>0&&level[e.to]==level[u]+1){int f=dfsFlow(g,e.to,t,Math.min(pushed,e.cap),level,ptr);if(f>0){e.cap-=f;g.e[e.to][e.rev].cap+=f;return f;}}ptr[u]++;}return 0;}
    static int dinic(FlowGraph g,int s,int t){int flow=0;int[] level=new int[g.n],ptr=new int[g.n];while(bfsLevel(g,s,t,level)){for(int i=0;i<g.n;i++)ptr[i]=0;int f;while((f=dfsFlow(g,s,t,1000000000,level,ptr))>0)flow+=f;}return flow;}
    static int edmondsKarp(FlowGraph g,int s,int t){int flow=0;while(true){int[] parV=new int[g.n],parE=new int[g.n],q=new int[g.n+1];for(int i=0;i<g.n;i++)parV[i]=-1;int h=0,z=0;q[z++]=s;parV[s]=s;while(h<z&&parV[t]<0){int u=q[h++];for(int j=0;j<g.deg[u];j++){FlowEdge e=g.e[u][j];if(e.cap>0&&parV[e.to]<0){parV[e.to]=u;parE[e.to]=j;q[z++]=e.to;}}}if(parV[t]<0)break;int f=1000000000;for(int v=t;v!=s;v=parV[v])f=Math.min(f,g.e[parV[v]][parE[v]].cap);for(int v=t;v!=s;v=parV[v]){FlowEdge e=g.e[parV[v]][parE[v]];e.cap-=f;g.e[v][e.rev].cap+=f;}flow+=f;}return flow;}
    static boolean[] reachableResidual(FlowGraph g,int s){boolean[] seen=new boolean[g.n];int[] q=new int[g.n+1];int h=0,z=0;q[z++]=s;seen[s]=true;while(h<z){int u=q[h++];for(int i=0;i<g.deg[u];i++){FlowEdge e=g.e[u][i];if(e.cap>0&&!seen[e.to]){seen[e.to]=true;q[z++]=e.to;}}}return seen;}
    static int minCostMaxFlow(FlowGraph g,int s,int t){int flow=0,cost=0;int n=g.n;while(true){int[] d=new int[n],pv=new int[n],pe=new int[n];boolean[] in=new boolean[n];for(int i=0;i<n;i++){d[i]=1000000000;pv[i]=-1;}d[s]=0;int[] q=new int[10000];int head=0,tail=0;q[tail++]=s;in[s]=true;while(head<tail){int u=q[head++];in[u]=false;for(int j=0;j<g.deg[u];j++){FlowEdge e=g.e[u][j];if(e.cap>0&&d[e.to]>d[u]+e.cost){d[e.to]=d[u]+e.cost;pv[e.to]=u;pe[e.to]=j;if(!in[e.to]&&tail<q.length){q[tail++]=e.to;in[e.to]=true;}}}}if(pv[t]<0)break;int f=1000000000;for(int v=t;v!=s;v=pv[v])f=Math.min(f,g.e[pv[v]][pe[v]].cap);for(int v=t;v!=s;v=pv[v]){FlowEdge e=g.e[pv[v]][pe[v]];e.cap-=f;g.e[v][e.rev].cap+=f;cost+=f*e.cost;}flow+=f;}System.out.println("Min-cost max-flow result: flow="+flow+", cost="+cost);return flow;}
    static void projectSelectionDemo(){// project profits: 5, 4; costs: 3; project 0 requires project 2
        int source=0,p0=1,p1=2,p2=3,sink=4;FlowGraph g=new FlowGraph(5,8);g.add(source,p0,5);g.add(source,p1,4);g.add(p2,sink,3);g.add(p0,p2,1000000);int cut=dinic(g,source,sink);System.out.println("Project-selection min-cut demo: total positive profit=9, min-cut cost="+cut+", maximum net value="+(9-cut));System.out.println("Dependency edge uses INF capacity; the min-cut chooses a feasible project set. Image segmentation uses a similar source/sink labeling reduction.");}
    static void flowDemo(){System.out.println("\n--- Network Flow ---");FlowGraph g=new FlowGraph(6,12);g.add(0,1,16);g.add(0,2,13);g.add(1,2,10);g.add(2,1,4);g.add(1,3,12);g.add(3,2,9);g.add(2,4,14);g.add(4,3,7);g.add(3,5,20);g.add(4,5,4);int f=dinic(g,0,5);System.out.println("Dinic max flow = "+f+" (classic example expected 23)");boolean[] side=reachableResidual(g,0);System.out.print("Min-cut source side: ");for(int i=0;i<side.length;i++)if(side[i])System.out.print(i+" ");System.out.println();FlowGraph ek=new FlowGraph(4,8);ek.add(0,1,3);ek.add(0,2,2);ek.add(1,2,1);ek.add(1,3,2);ek.add(2,3,3);System.out.println("Edmonds-Karp sample max flow = "+edmondsKarp(ek,0,3));FlowGraph mc=new FlowGraph(4,8);mc.addCost(0,1,1,1);mc.addCost(0,2,1,0);mc.addCost(1,3,1,2);mc.addCost(2,3,1,5);minCostMaxFlow(mc,0,3);projectSelectionDemo();System.out.println("Deadline scheduling can be reduced to flow when jobs, time slots and capacities are represented as a network.");System.out.println("Applications: bipartite matching, project selection, image segmentation, deadline scheduling.");}
    static boolean augment(int u,boolean[][] adj,boolean[] seen,int[] owner){for(int v=0;v<adj[u].length;v++)if(adj[u][v]&&!seen[v]){seen[v]=true;if(owner[v]<0||augment(owner[v],adj,seen,owner)){owner[v]=u;return true;}}return false;}
    static void matchingDemo(){boolean[][] a={{true,true,false},{false,true,true},{true,false,true}};int[] owner={-1,-1,-1};int count=0;for(int u=0;u<a.length;u++)if(augment(u,a,new boolean[3],owner))count++;System.out.println("Bipartite matching size = "+count+" of 3 possible assignments.");for(int v=0;v<owner.length;v++)System.out.println("Right node "+v+" assigned to left node "+owner[v]);System.out.println("König's theorem: maximum matching size equals minimum vertex-cover size in bipartite graphs.");}

    // -------------------- Module 5: NP-hardness and approximation --------------------
    static void vertexCoverApprox(){int[][] edges={{0,1},{1,2},{2,3},{3,4},{4,0},{1,3}};boolean[] picked=new boolean[5];int chosen=0;for(int i=0;i<edges.length;i++){int u=edges[i][0],v=edges[i][1];if(!picked[u]&&!picked[v]){picked[u]=true;picked[v]=true;chosen+=2;}}System.out.print("Vertex-cover 2-approx selected vertices: ");for(int i=0;i<picked.length;i++)if(picked[i])System.out.print(i+" ");System.out.println("\nCover size="+chosen+"; guaranteed at most twice optimum (standard maximal-matching construction).");}
    static void setCoverDemo(){String[] universe={"AI","sports","science","education","technology"};String[][] sets={{"AI","sports","science"},{"AI","technology"},{"education","technology"},{"science","technology"}};boolean[] covered=new boolean[universe.length],used=new boolean[sets.length];int left=universe.length;System.out.println("Greedy set cover selections:");while(left>0){int best=-1,gainBest=0;for(int s=0;s<sets.length;s++)if(!used[s]){int gain=0;for(int j=0;j<sets[s].length;j++)for(int u=0;u<universe.length;u++)if(!covered[u]&&universe[u].equals(sets[s][j]))gain++;if(gain>gainBest){gainBest=gain;best=s;}}if(best<0)break;used[best]=true;System.out.println("  Source "+(best+1)+" adds "+gainBest+" uncovered topics");for(int j=0;j<sets[best].length;j++)for(int u=0;u<universe.length;u++)if(!covered[u]&&universe[u].equals(sets[best][j])){covered[u]=true;left--;}}System.out.println("Covered "+(universe.length-left)+"/"+universe.length+" topics.");}
    static boolean subsetSum(int[] a,int target){if(target<0||target>100000)return false;boolean[] dp=new boolean[target+1];dp[0]=true;for(int i=0;i<a.length;i++)for(int s=target;s>=a[i];s--)if(dp[s-a[i]])dp[s]=true;return dp[target];}
    static void schedulingApprox(){int[] jobs={8,7,6,5,4,3,2};int[] load={0,0,0};System.out.println("List-scheduling jobs [8,7,6,5,4,3,2] on 3 machines:");for(int i=0;i<jobs.length;i++){int m=0;for(int j=1;j<load.length;j++)if(load[j]<load[m])m=j;System.out.println("job "+jobs[i]+" -> machine "+m);load[m]+=jobs[i];}System.out.println("Machine loads: "+ints(load)+"; makespan="+Math.max(load[0],Math.max(load[1],load[2]))+". This is a scheduling approximation, not an exact NP-hard optimizer.");}
    static void complexityMenu(){System.out.println("\n--- NP-completeness and Approximation ---");System.out.println("P: decision problems solvable in polynomial time.");System.out.println("NP: proposed yes-witness can be verified in polynomial time.");System.out.println("co-NP: complements of NP languages; P is contained in NP and co-NP.");System.out.println("NP-complete: in NP and every NP problem reduces to it in polynomial time.");System.out.println("Reduction chain: 3-SAT -> CLIQUE -> INDEPENDENT SET -> VERTEX COVER.");System.out.println("Other canonical problems: SUBSET-SUM, KNAPSACK, HAM-CYCLE, TSP.");vertexCoverApprox();setCoverDemo();System.out.println("Subset sum [3, 5, 7, 10], target 15 = "+subsetSum(new int[]{3,5,7,10},15));schedulingApprox();System.out.println("PTAS: polynomial time for fixed epsilon; FPTAS polynomial in input and 1/epsilon; APX has constant-factor approximation.");System.out.println("FPT: f(k)*poly(n); kernelisation compresses an instance to size bounded by parameter k.");System.out.println("Cook-Levin: SAT is NP-complete; reductions are evidence of hardness, not proof that P != NP.");}

    // -------------------- Module 6: Randomized and parallel algorithms --------------------
    static long nextRandom(){randomState^=randomState<<13;randomState^=randomState>>>7;randomState^=randomState<<17;return randomState&Long.MAX_VALUE;}
    static long randomState=System.nanoTime()|1L;
    static void randomizedQuickSort(int[] a,int lo,int hi){if(lo>=hi)return;int p=lo+(int)(nextRandom()%(hi-lo+1));swap(a,p,hi);int pivot=a[hi],i=lo;for(int j=lo;j<hi;j++)if(a[j]<=pivot){swap(a,i,j);i++;}swap(a,i,hi);randomizedQuickSort(a,lo,i-1);randomizedQuickSort(a,i+1,hi);}
    static boolean millerRabin(long n){if(n<2)return false;long[] small={2,3,5,7,11,13,17,19,23,29,31,37};for(int i=0;i<small.length;i++){if(n==small[i])return true;if(n%small[i]==0)return false;}long d=n-1;int s=0;while((d&1)==0){d>>=1;s++;}long[] bases={2,325,9375,28178,450775,9780504,1795265022};for(int i=0;i<bases.length;i++){long a=bases[i]%n;if(a==0)continue;long x=modPow(a,d,n);if(x==1||x==n-1)continue;boolean pass=false;for(int r=1;r<s;r++){x=(x*x)%n;if(x==n-1){pass=true;break;}}if(!pass)return false;}return true;}
    static void reservoirSampling(){int[] stream={10,20,30,40,50,60,70,80,90,100};int k=3;int[] sample=new int[k];for(int i=0;i<k;i++)sample[i]=stream[i];for(int i=k;i<stream.length;i++){int j=(int)(nextRandom()%(i+1));if(j<k)sample[j]=stream[i];}System.out.println("Reservoir sample of size 3 from stream: "+ints(sample));System.out.println("Each stream item has equal probability k/n of being retained.");}
    static int universalHash(int key,int a,int b,int prime,int buckets){long x=((long)a*key+b)%prime;return (int)(x%buckets);}
    static void parallelDemo(){final int n=100000;final int[] values=new int[n];for(int i=0;i<n;i++)values[i]=i+1;final long[] sums=new long[4];Thread[] threads=new Thread[4];long start=System.nanoTime();for(int p=0;p<4;p++){final int part=p;threads[p]=new Thread(new Runnable(){public void run(){int lo=part*n/4,hi=(part+1)*n/4;long s=0;for(int i=lo;i<hi;i++)s+=values[i];sums[part]=s;}});threads[p].start();}for(int p=0;p<4;p++)try{threads[p].join();}catch(InterruptedException e){Thread.currentThread().interrupt();}long total=sums[0]+sums[1]+sums[2]+sums[3];long elapsed=System.nanoTime()-start;int[] prefix={1,2,3,4,5,6,7,8};for(int i=1;i<prefix.length;i++)prefix[i]+=prefix[i-1];int[] blelloch={1,2,3,4,5,6,7,8};for(int stride=1;stride<blelloch.length;stride*=2)for(int i=0;i<blelloch.length;i+=2*stride)blelloch[i+2*stride-1]+=blelloch[i+stride-1];blelloch[blelloch.length-1]=0;for(int stride=blelloch.length/2;stride>=1;stride/=2)for(int i=0;i<blelloch.length;i+=2*stride){int left=i+stride-1,right=i+2*stride-1;int t=blelloch[left];blelloch[left]=blelloch[right];blelloch[right]+=t;}System.out.println("Parallel reduce sum(1..100000) = "+total+"; elapsed ns="+elapsed);System.out.println("Inclusive prefix scan example = "+ints(prefix));System.out.println("Blelloch exclusive scan example = "+ints(blelloch));System.out.println("Work T1=O(n), span idealized T-infinity=O(n/p + log p) for tree reduction; speedup is limited by overhead and serial work.");System.out.println("Parallel styles: data-parallel splits arrays; task-parallel runs independent tasks; embarrassingly parallel tasks have little communication.");}
    static void randomizedMenu(){System.out.println("\n--- Generate quick insights from news data ---");long[] samples={1000003L,1000005L,7919L,100L};System.out.println("Choose a sample number to analyse:");System.out.println(" 1. 1000003 (prime example)");System.out.println(" 2. 1000005 (composite example)");System.out.println(" 3. 7919 (prime example)");System.out.println(" 4. 100 (composite example)");int pick=readInt("Choose a number: ",1,4);long n=samples[pick-1];System.out.println(n+" is "+(millerRabin(n)?"probably prime":"composite")+" under fixed Miller-Rabin bases.");int[] a={14,3,7,2,19,8,1,11,5};randomizedQuickSort(a,0,a.length-1);System.out.println("Randomized quicksort result: "+ints(a));reservoirSampling();System.out.println("Universal hash example h(12345) = "+universalHash(12345,37,17,100003,101));System.out.println("Las Vegas: always correct, random running time (randomized quicksort). Monte Carlo: bounded error probability (Miller-Rabin).");System.out.println("Miller-Rabin uses deterministic proven bases for positive signed 64-bit values with overflow-safe modular multiplication.");System.out.println("Suffix automaton preview: compact state machine recognises all substrings; suffix tree preview: compressed suffix trie supports substring queries and repeats.");System.out.println("Universal hashing: choose a hash function randomly from a family to limit adversarial collisions; perfect hashing is collision-free for a fixed key set.");parallelDemo();}
    static long readLong(String prompt,long min,long max){while(true){String s=read(prompt);try{long x=Long.parseLong(s);if(x>=min&&x<=max)return x;}catch(NumberFormatException ignored){}System.out.println("Enter a valid integer >= "+min+".");}}

    // -------------------- Similarity / citation flow / API-like query router --------------------
    static int wordCount(String s){if(s.trim().length()==0)return 0;int c=1;for(int i=0;i<s.length();i++)if(Character.isWhitespace(s.charAt(i))&&i+1<s.length()&&!Character.isWhitespace(s.charAt(i+1)))c++;return c;}
    static boolean hasWord(String text,String word){String[]dummy=null;String low=text.toLowerCase(),w=word.toLowerCase();int i=low.indexOf(w);while(i>=0){boolean left=i==0||!Character.isLetterOrDigit(low.charAt(i-1));int end=i+w.length();boolean right=end==low.length()||!Character.isLetterOrDigit(low.charAt(end));if(left&&right)return true;i=low.indexOf(w,i+1);}return false;}
    static double jaccard(String a,String b){String[] wa=a.toLowerCase().split("[^a-z0-9]+");String[] wb=b.toLowerCase().split("[^a-z0-9]+");int inter=0,union=0;for(int i=0;i<wa.length;i++){if(wa[i].length()==0)continue;boolean seen=false;for(int j=0;j<i;j++)if(wa[i].equals(wa[j]))seen=true;if(seen)continue;boolean inB=false;for(int j=0;j<wb.length;j++)if(wa[i].equals(wb[j]))inB=true;union++;if(inB)inter++;}for(int i=0;i<wb.length;i++){if(wb[i].length()==0)continue;boolean seen=false;for(int j=0;j<i;j++)if(wb[i].equals(wb[j]))seen=true;if(seen)continue;boolean inA=false;for(int j=0;j<wa.length;j++)if(wb[i].equals(wa[j]))inA=true;if(!inA)union++;}return union==0?0.0:(double)inter/union;}
    static int minHashSignature(String text,int seed){String[] w=text.toLowerCase().split("[^a-z0-9]+");int min=Integer.MAX_VALUE;for(int i=0;i<w.length;i++)if(w[i].length()>0){int h=seed*0x45d9f3b;for(int j=0;j<w[i].length();j++)h=(h^w[i].charAt(j))*0x45d9f3b;h^=h>>>16;if(h<min)min=h;}return min;}
    static void similarityDemo(){System.out.println("Choose two articles to compare:");Article x=chooseArticle("Choose first article: ");if(x==null)return;Article y=chooseArticle("Choose second article: ");if(y==null)return;System.out.printf("Jaccard token similarity: %.3f%n",jaccard(x.content,y.content));int same=0,k=64;for(int i=1;i<=k;i++)if(minHashSignature(x.content,i)==minHashSignature(y.content,i))same++;System.out.printf("MinHash estimate (%d independent-ish seeded signatures): %.3f%n",k,(double)same/k);System.out.println("MinHash estimates Jaccard similarity; this educational version uses simple seeded hashes, not a production LSH index.");}
    static void citationFlowDemo(){System.out.println("Citation-flow model: article nodes linked by directed citations.");FlowGraph g=new FlowGraph(6,16);g.add(0,1,3);g.add(0,2,2);g.add(1,3,2);g.add(2,3,1);g.add(1,4,1);g.add(3,5,3);g.add(4,5,1);g.add(2,4,1);System.out.println("Maximum citation-path capacity from source concept 0 to target concept 5 = "+dinic(g,0,5));System.out.println("This is a synthetic capacity model; real citation links and capacities must be loaded from a corpus.");}
    static void searchAll(String query,int algorithm){boolean found=false;for(int i=0;i<articleCount;i++){String text=articles[i].searchable().toLowerCase(),p=query.toLowerCase();int pos=algorithm==1?kmp(text,p):algorithm==2?zSearch(text,p):rabinKarp(text,p);if(pos>=0){articles[i].print();found=true;}}if(!found)System.out.println("No articles matched.");}
    static void queryRouter(){
        System.out.println("\n--- Ask TextHack (local query interface) ---");
        System.out.println("1 Find a phrase in news");
        System.out.println("2 Find stories even when words are misspelled");
        System.out.println("3 Discover stories similar to each other");
        System.out.println("4 Explore how stories connect");
        System.out.println("5 Plan a schedule for reading topics");
        System.out.println("6 Check a number for primality (demo)");
        int c=readInt("What would you like to do? ",1,6);
        switch(c){
            case 1:{String q=chooseSearchPhrase();if(q!=null)searchAll(q,1);break;}
            case 2:{String[] q={"artificial inteligence","criket","tecnology","educaton"};for(int i=0;i<q.length;i++)System.out.println(" "+(i+1)+". "+q[i]);int k=readInt("Choose sample phrase: ",1,q.length);fuzzySearch(q[k-1]);break;}
            case 3:similarityDemo();break;
            case 4:citationFlowDemo();break;
            case 5:schedulingApprox();break;
            case 6:{long[] samples={1000003L,1000005L,7919L,100L};for(int i=0;i<samples.length;i++)System.out.println(" "+(i+1)+". Check "+samples[i]);int k=readInt("Choose a number: ",1,samples.length);long n=samples[k-1];System.out.println(n+" is "+(millerRabin(n)?"probably prime":"composite"));break;}
        }
    }

    // -------------------- System, costs, full test run --------------------
    static void costTable(){System.out.println("\nAlgorithm | Typical time | Space");System.out.println("Naive string search | O(nm) | O(1)");System.out.println("KMP / Z | O(n+m) | O(m) / O(n+m)");System.out.println("Rabin-Karp | expected O(n+m), worst O(nm) | O(1)");System.out.println("Aho-Corasick | O(total pattern length + text + matches) | trie size");System.out.println("Levenshtein DP | O(nm) | O(nm), optimisable to O(min(n,m))");System.out.println("Suffix array here | O(n log^2 n) | O(n)");System.out.println("Kasai LCP | O(n) | O(n)");System.out.println("Bitmask TSP | O(2^n n^2) | O(2^n n)");System.out.println("Dinic general bound | O(V^2 E) | O(V+E)");System.out.println("Edmonds-Karp | O(V E^2) | O(V+E)");System.out.println("Vertex-cover approximation | O(V+E) | O(V+E)");System.out.println("Miller-Rabin | O(k log^3 n) with standard multiplication | O(1) extra");System.out.println("Parallel reduce | O(n) work; ideal span O(n/p + log p) | O(p)");}
    static void fullDemo(){System.out.println("\n========== FULL TEXT HACK DEMONSTRATION ==========");System.out.println("Corpus documents: "+articleCount);System.out.println("KMP finds 'artificial intelligence': "+(kmp(articles[0].searchable().toLowerCase(),"artificial intelligence")>=0));System.out.println("Z finds 'Hyderabad': "+(zSearch(articles[1].searchable().toLowerCase(),"hyderabad")>=0));System.out.println("Double-hash Rabin-Karp finds 'renewable energy': "+(rabinKarp(articles[4].searchable().toLowerCase(),"renewable energy")>=0));System.out.println("Edit distance kitten/sitting = "+editDistance("kitten","sitting"));System.out.println("Suffix array of 'banana' = "+ints(suffixArray("banana")));System.out.println("LCP of 'banana' = "+ints(lcpArray("banana",suffixArray("banana"))));System.out.println("Bitmask TSP sample = "+tspBitmask(new int[][]{{0,10,15,20},{10,0,35,25},{15,35,0,30},{20,25,30,0}}));System.out.println("Subset sum [3,5,7,10] target 15 = "+subsetSum(new int[]{3,5,7,10},15));System.out.println("Miller-Rabin 1000003 = "+millerRabin(1000003));System.out.println("All quick smoke-test demonstrations executed; use individual menu items for complete output.");}
    static void menu(){
        System.out.println("\n====================================================");
        System.out.println(" TRENDING NEWS EXPLORER / TEXTHACK");
        System.out.println("====================================================");
        System.out.println(" 1. Explore news headlines");
        System.out.println(" 2. Browse news by topic");
        System.out.println(" 3. Search a phrase across the news");
        System.out.println(" 4. Find an exact phrase in articles");
        System.out.println(" 5. Search even if you make a spelling mistake");
        System.out.println(" 6. Track several topics at once");
        System.out.println(" 7. Discover repeated phrases in a story");
        System.out.println(" 8. Find stories with similar content");
        System.out.println(" 9. Personalize your reading feed");
        System.out.println("10. Explore story routes and connections");
        System.out.println("11. Match topics with relevant stories");
        System.out.println("12. Plan coverage across many news topics");
        System.out.println("13. Generate quick insights from news data");
        System.out.println("14. Explore how stories cite or connect to others");
        System.out.println("15. Ask TextHack a question");
        System.out.println("16. View the search performance guide");
        System.out.println("17. Run a complete app self-check");
        System.out.println(" 0. Exit");
    }
    public static void main(String[] args){
        loadCorpus();
        System.out.println("Loaded "+articleCount+" sample news and knowledge stories.");
        System.out.println("News content is bundled locally for offline reading; no websites are contacted.");
        while(true){
            menu();
            int c=readInt("Choose an option (0-17): ",0,17);
            switch(c){
                case 0:System.out.println("Thanks for exploring TextHack.");return;
                case 1:printCorpus();break;
                case 2:browseNewsByTopic();break;
                case 3:{String q=chooseSearchPhrase();if(q!=null)searchAll(q,2);break;}
                case 4:{String q=chooseSearchPhrase();if(q!=null)searchAll(q,3);break;}
                case 5:{String[] q={"artificial inteligence","criket","tecnology","educaton","renewble energy"};System.out.println("Choose a phrase with a sample spelling mistake:");for(int i=0;i<q.length;i++)System.out.println(" "+(i+1)+". "+q[i]);int k=readInt("Choose a phrase: ",1,q.length);fuzzySearch(q[k-1]);break;}
                case 6:{String[] p={"india","technology","research","education","cricket"};Article a=chooseArticle("Choose news to scan: ");if(a!=null)ahoDemo(a.title+" "+a.content,p);break;}
                case 7:{Article a=chooseArticle("Choose news to explore: ");if(a==null)break;String s=a.title+" "+a.content;int[] sa=suffixArray(s);System.out.println("Repeated-phrase exploration for: "+a.title);System.out.println("Suffix positions: "+ints(sa));System.out.println("Shared-prefix lengths: "+ints(lcpArray(s,sa)));for(int i=0;i<sa.length;i++)System.out.println("From position "+sa[i]+": "+s.substring(sa[i]));break;}
                case 8:similarityDemo();break;
                case 9:dpMenu();break;
                case 10:flowDemo();break;
                case 11:matchingDemo();break;
                case 12:complexityMenu();break;
                case 13:randomizedMenu();break;
                case 14:citationFlowDemo();break;
                case 15:queryRouter();break;
                case 16:costTable();break;
                case 17:fullDemo();break;
                default:break;
            }
        }
    }
}
