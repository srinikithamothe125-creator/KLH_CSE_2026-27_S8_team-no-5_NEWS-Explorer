# Syllabus Mapping — News Explorer / TextHack

## Module 1 — TextHack as a System
- Local query router: menu option 15 routes pattern search, fuzzy search, similarity, citation flow, scheduling, and primality queries.
- Sample corpus and article metadata are embedded in `loadCorpus()`.
- `costTable()` reports asymptotic costs.
- `fullDemo()` provides a first end-to-end smoke test.
- Limitation: this is a local API-style console interface, not an HTTP public API; the corpus is a small educational sample, not a full Wikipedia corpus.

## Module 2 — String Algorithms
- Naive baseline is discussed in documentation; KMP: `buildLps`, `kmp`.
- Z-function: `zFunction`, `zSearch`.
- Double modular Rabin–Karp: `rabinKarp`.
- Multi-pattern trie with failure links: `ahoDemo`.
- Practical suffix array by prefix doubling: `suffixArray`; Kasai LCP: `lcpArray`.
- SA-IS, suffix automata, and suffix trees are explained as conceptual previews; SA-IS and full suffix automaton/tree construction are not claimed as implemented.

## Module 3 — Advanced Dynamic Programming
- Levenshtein, Damerau-Levenshtein and weighted edit distance.
- Needleman–Wunsch global alignment and Smith–Waterman local alignment.
- Matrix-chain multiplication and optimal BST interval DP.
- Bitmask TSP and Hamiltonian-path detection.
- Tree subtree-sum DP, height/diameter intuition, rerooting and centroid concepts.
- Sum-over-subsets (SOS) DP.
- Exponential-state caveats are covered in menu explanations and README.

## Module 4 — Network Flow
- Residual graph and integer capacities: `FlowGraph`.
- Dinic: `dinic`, `bfsLevel`, `dfsFlow`.
- Edmonds–Karp: `edmondsKarp`.
- Residual reachability for min-cut: `reachableResidual`.
- Bipartite matching via augmenting paths: `matchingDemo`, `augment`.
- Min-cost max-flow using successive shortest augmenting paths (SPFA-style shortest path): `minCostMaxFlow`.
- Citation flow is a synthetic capacity-network demonstration.

## Module 5 — NP-Completeness and Approximation
- P, NP, co-NP, NP-completeness, polynomial reductions and canonical reduction chain: `complexityMenu`.
- Vertex-cover 2-approximation: `vertexCoverApprox`.
- Greedy set cover: `setCoverDemo`.
- Subset sum DP and list scheduling approximation: `subsetSum`, `schedulingApprox`.
- PTAS/FPTAS/APX and FPT/kernelisation definitions are presented in the console.

## Module 6 — Randomised and Parallel Algorithms
- Las Vegas vs Monte Carlo concepts; randomized quicksort: `randomizedQuickSort`.
- Miller–Rabin primality test with modular arithmetic helpers: `millerRabin`, `modPow`, `mulMod`.
- Reservoir sampling: `reservoirSampling`.
- Universal-hash family example: `universalHash`; perfect hashing is explained conceptually.
- Parallel reduction with four Java threads, prefix sum and Blelloch exclusive scan: `parallelDemo`.
- Work/span and parallelism limitations are explained in output.

## Restriction check
The source has no `java.util.*` imports or Java Collections usage in the engine. It uses `java.io.BufferedReader`, `InputStreamReader`, and `IOException` for console I/O.
