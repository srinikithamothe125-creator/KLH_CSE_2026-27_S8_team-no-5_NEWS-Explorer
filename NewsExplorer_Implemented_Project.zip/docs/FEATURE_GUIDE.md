# Feature Guide: What Each News Explorer Option Demonstrates

The main menu is written for a normal news-reader user. Algorithm names are kept here for the project report and faculty review; they are not shown as the main menu choices.

| Main-menu option | User-facing feature | Concepts implemented behind the scenes | Main source methods |
|---:|---|---|---|
| 1 | Explore news headlines | Local corpus browsing and article metadata | `loadCorpus`, `printCorpus`, `Article.print` |
| 2 | Find stories about a topic | Knuth–Morris–Pratt (KMP) string matching | `searchAll`, `kmp`, `buildLps` |
| 3 | Search a phrase across the news | Z-function pattern matching | `searchAll`, `zSearch`, `zFunction` |
| 4 | Find an exact phrase in articles | Double-hash Rabin–Karp string matching | `searchAll`, `rabinKarp` |
| 5 | Search even if you make a spelling mistake | Levenshtein and Damerau–Levenshtein edit-distance dynamic programming | `fuzzySearch`, edit-distance methods |
| 6 | Track several topics at once | Aho–Corasick trie, failure links, multi-pattern matching | `ahoDemo` |
| 7 | Discover repeated phrases in a story | Suffix array and Kasai longest-common-prefix (LCP) array | `suffixArray`, `lcpArray` |
| 8 | Find stories with similar content | Jaccard similarity and seeded MinHash signatures | `similarityDemo`, `jaccard`, `minHashSignature` |
| 9 | Personalize your reading feed | Edit-distance DP, sequence alignment, interval DP, bitmask DP, tree DP, SOS DP | `dpMenu` and related DP methods |
| 10 | Explore story routes and connections | Maximum flow, residual networks, minimum cut, Edmonds–Karp, min-cost max-flow | `flowDemo`, `dinic`, `edmondsKarp`, `minCostMaxFlow` |
| 11 | Match topics with relevant stories | Bipartite matching using augmenting paths | `matchingDemo`, `augment` |
| 12 | Plan coverage across many news topics | NP-hardness and reductions, vertex-cover 2-approximation, greedy set cover, subset-sum DP, list scheduling | `complexityMenu`, approximation methods |
| 13 | Generate quick insights from news data | Randomized quicksort, Miller–Rabin primality testing, reservoir sampling, hashing, parallel reduction and prefix scan | `randomizedMenu`, `parallelDemo` |
| 14 | Explore how stories cite or connect to others | Synthetic directed-capacity graph and maximum-flow model | `citationFlowDemo` |
| 15 | Ask TextHack a question | Local query router that dispatches to search, fuzzy search, similarity, story connections, scheduling, or primality demo | `queryRouter` |
| 16 | View the search performance guide | Time/space complexity summary for implemented demonstrations | `costTable` |
| 17 | Run a complete app self-check | Representative end-to-end checks across search, DP, suffix structures, and randomized testing | `fullDemo` |

## Important scope notes
- The included corpus is a small, bundled educational sample. It is not a live or continuously updated news feed.
- TextHack's query router is a console/API-style simulation, not an HTTP server.
- Suffix-array construction uses prefix doubling; SA-IS, suffix automata, and suffix trees are described as syllabus previews rather than full implementations.
- MinHash is an educational similarity estimate, not a production LSH search service.
- Options 9, 10, 12, and 13 open demonstrations that print technical details for learning and assessment. The main menu itself uses user-facing feature names.
