# Offline News Reader

Option 2 is **Browse news by topic**. Choose a topic, select a news headline, and read the complete paragraph and key points in the terminal.

## Example flow
1. Main menu: `2. Browse news by topic`
2. Select `3. Sports`
3. Select a listed headline
4. The app prints the title, topic, reading-time estimate, article paragraph, and key points.

## Offline behaviour
- No websites, APIs, RSS feeds, or network connections are used by the news browsing feature.
- News articles are sample educational content bundled in `src/NewsExplorer.java`.
- The sample headlines are not verified real-time news. The article text is written for demonstration and should not be presented as factual reporting of a specific current event.
- To add another article, add another `add(...)` entry inside `loadCorpus()`, using one of the existing categories.

## Run
```powershell
javac -encoding UTF-8 -d out src\NewsExplorer.java
java -cp out NewsExplorer
```
