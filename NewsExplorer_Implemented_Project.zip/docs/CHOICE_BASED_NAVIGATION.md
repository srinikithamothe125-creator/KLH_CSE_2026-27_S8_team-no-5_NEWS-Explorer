# Choice-Based Navigation

The app uses numbered menus for search inputs instead of asking the reader to type a phrase, topic, article, or sample number.

- Option 2: choose a topic, then choose a news article to read.
- Option 3: choose a phrase from a preset list and search the corpus.
- Option 4: choose an exact phrase from a preset list.
- Option 5: choose a sample misspelled phrase for fuzzy search.
- Option 6: choose an article to scan for multiple topics.
- Option 7: choose an article to explore repeated phrases.
- Option 8: choose two articles to compare.
- Option 9: choose a preset comparison for the feed/DP demonstration.
- Option 13: choose a preset number for the randomized-algorithm demonstration.
- Option 15: the query router also offers numbered choices.

All news is bundled sample content. No websites, APIs, or RSS feeds are contacted.
