# News Explorer / TextHack — Advanced Algorithms Project

## Overview
A menu-driven Java console system that demonstrates the six syllabus modules through a small local news/language-tech corpus. The program provides a single query router and runnable demonstrations for string algorithms, dynamic programming, network flow, approximation, randomized algorithms, and parallel primitives.

## Requirements
- JDK 8 or later
- VS Code or any Java IDE (optional)
- No third-party dependencies
- The algorithm engine does not import `java.util.*`; it uses custom arrays/queues/graph structures. `java.io` is used for console input.

## Compile and run (Windows PowerShell / Command Prompt)
From the `NewsExplorerFinal` folder:

```powershell
javac -encoding UTF-8 -d out src\NewsExplorer.java
java -cp out NewsExplorer
```

Linux/macOS:

```bash
javac -encoding UTF-8 -d out src/NewsExplorer.java
java -cp out NewsExplorer
```

## Main menu (user-facing features)
1. Explore news headlines
2. Browse news by topic
3. Search a phrase across the news
4. Find an exact phrase in articles
5. Search even if you make a spelling mistake
6. Track several topics at once
7. Discover repeated phrases in a story
8. Find stories with similar content
9. Personalize your reading feed
10. Explore story routes and connections
11. Match topics with relevant stories
12. Plan coverage across many news topics
13. Generate quick insights from news data
14. Explore how stories cite or connect to others
15. Ask TextHack a question
16. View the search performance guide
17. Run a complete app self-check
0. Exit

See `docs/FEATURE_GUIDE.md` for the exact mapping from each user-facing feature to the algorithms and syllabus concepts implemented behind it.
## Live news browser
Menu option 2 fetches current topic headlines from Google News RSS when an internet connection is available. Select a topic, then a headline to see the available summary and original publisher URL. RSS usually does not contain the complete article; open the publisher link to read the full report. If the feed is unreachable, the app uses clearly labelled bundled sample news. See `docs/LIVE_NEWS_GUIDE.md`.

## Corpus and limitations
The source embeds 18 educational sample documents, including Telugu-script examples. It is **not** a full Indian-language Wikipedia dump. The live topic browser fetches headlines and summaries from an RSS feed when online, but does not download full publisher articles. For an authentic corpus, use a permitted Wikipedia/Wikimedia export and adapt `loadCorpus()` to load the text from files. The query router is an API-style local interface, not an HTTP server or a live public API.

## Algorithmic scope and honest implementation notes
- Suffix arrays use prefix-doubling with merge sort, `O(n log^2 n)`; SA-IS is described at conceptual level, as allowed by the syllabus.
- Suffix automata and suffix trees are previewed conceptually; no full suffix automaton/tree builder is claimed.
- MinHash is an educational signature approximation; a production LSH index would require banding/bucket indexing and careful hash-family design.
- The scheduling demonstration is list scheduling (approximation), not an exact optimizer for NP-hard scheduling.
- Parallelism uses Java threads to demonstrate work/span and reduction; JVM scheduling means measured time is environment-dependent. The Blelloch scan is a compact illustrative implementation for a power-of-two input.
- Randomized quicksort uses a pseudo-random xorshift generator. Miller–Rabin uses a deterministic base set for positive signed 64-bit integers with overflow-safe modular multiplication.
- Citation capacities are synthetic; the program does not contain a real citation graph.

## Syllabus map
See `docs/SYLLABUS_MAPPING.md` for a module-by-module map, and `docs/TESTING.md` for smoke-test commands.


## Offline topic-based news reading

Choose **2. Browse news by topic**, choose a topic such as Sports, select a headline, and read the full bundled paragraph and key points in the terminal. This feature intentionally makes no network or website connections. The content is sample educational text, not verified real-time news. See `docs/OFFLINE_NEWS_READER.md`.
